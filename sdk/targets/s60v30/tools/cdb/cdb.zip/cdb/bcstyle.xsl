<?xml version="1.0"  encoding="ISO-8859-1"?>
<xsl:stylesheet 
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
    version="1.0"
    > 
    <xsl:output method="html"/> 

<!-- Colours for API classification -->
<xsl:param name="notSpecified">#ff9900</xsl:param>
<xsl:param name="publishedAll">red</xsl:param>
<xsl:param name="publishedPartner">red</xsl:param>
<xsl:param name="internalTechnology">green</xsl:param>
<xsl:param name="internalComponent">green</xsl:param>
<xsl:param name="internalAll">green</xsl:param>
<xsl:param name="notApplicable">#999999</xsl:param>


<!-- break descriptions -->
<xsl:param name="vtblItemAdded">Vtbl Item Added</xsl:param>
<xsl:param name="vtblItemMissing">Vtbl Item Missing</xsl:param>
<xsl:param name="vtblLayoutChanged">Vtbl Layout Changed</xsl:param>
<xsl:param name="vtblOverrideChanged">Vtbl Override Changed</xsl:param>

<xsl:param name="classMissing">Class Missing</xsl:param>
<xsl:param name="classDatumAdded">Class Datum Added</xsl:param>
<xsl:param name="classDatumMissing">Class Datum Missing</xsl:param>
<xsl:param name="classLayoutChanged">Class Layout Changed</xsl:param>
<xsl:param name="classSizeChanged">Class Size Changed</xsl:param>
<xsl:param name="classAbstractnessChanged">Class Abstractness Changed</xsl:param>

<xsl:param name="enumMissing">Enum Missing</xsl:param>
<xsl:param name="enumMissingValue">Enum Entry Missing</xsl:param>
<xsl:param name="enumValueAdded">Enum Entry Added</xsl:param>
<xsl:param name="enumValueChangedValue">Enum Entry Changed Value</xsl:param>
<xsl:param name="enumValueChangedName">Enum Entry Changed Name</xsl:param>
<xsl:param name="enumAnonymousBreak">Anonymous Enum Break</xsl:param>

<xsl:param name="ordinalItemMissing">Ordinal Item Missing</xsl:param>
<xsl:param name="ordinalLayoutChanged">Ordinal Layout Changed</xsl:param>

<xsl:param name="missingExe">Exe Missing</xsl:param>
<xsl:param name="exeTargetTypeChanged">Exe Targettype Changed</xsl:param>
<xsl:param name="exeDefFileChanged">Exe DEF File Changed</xsl:param>
<xsl:param name="exeMMPFileChanged">Exe MMP File Changed</xsl:param>
<xsl:param name="exeUIDChanged">Exe UID Changed</xsl:param>
<xsl:param name="exeCapabilityAdded">Exe Capability Added</xsl:param>
<xsl:param name="exeCapabilityMissing">Exe Capability Missing</xsl:param>

<xsl:param name="missingHeader">Header Missing</xsl:param>

<xsl:param name="resourceFileMissing">Resource File Missing</xsl:param>
<xsl:param name="resourceItemChanged">Resource Item Changed</xsl:param>
<xsl:param name="resourceItemNameChanged">Resource Item Name Changed</xsl:param>
<xsl:param name="resourceItemTypeChanged">Resource Item Type Changed</xsl:param>

<!-- global template match -->    
<xsl:template match="/">
    <xsl:apply-templates/>
</xsl:template>



<!-- This is used for the overall report-->
<xsl:template match="compatibilityReport">
    <HTML><basefont face="verdana" size="1" color="black"/>
     <TITLE>Compatibility Report</TITLE>   
    <H1><font color="#000099">CDB Compatibility Report</font></H1>
    <body>
        <xsl:apply-templates/>
        <p/>
        <hr/>
        <b>Api Classification of Breaks</b>
        <br/>
        <i>The colour of the break description indicates the API classification of the item which is broken</i>
        <br/>
        <table border="0">
            <tr>
                <td bgcolor="{$notSpecified}"><font size="1">&#160;</font></td>
                <td><font size="1">Not Specified</font></td>
                <td>&#160;</td><td>&#160;</td><td>&#160;</td>
                <td bgcolor="{$publishedAll}"><font size="1">&#160;</font></td>
                <td><font size="1">Published All</font></td>
                <td>&#160;</td><td>&#160;</td><td>&#160;</td>
                <td bgcolor="{$publishedPartner}"><font size="1">&#160;</font></td>
                <td><font size="1">Published Partner</font></td>
             </tr>
             <tr>
                <td bgcolor="{$internalTechnology}"><font size="1">&#160;</font></td>
                <td><font size="1">Internal Technology</font></td>
                <td>&#160;</td><td>&#160;</td><td>&#160;</td>
                <td bgcolor="{$internalComponent}"><font size="1">&#160;</font></td>
                <td><font size="1">Internal Component</font></td>
                <td>&#160;</td><td>&#160;</td><td>&#160;</td>
                <td bgcolor="{$internalAll}"><font size="1">&#160;</font></td>
                <td><font size="1">Internal All</font></td>
             </tr>   
             <tr>
                <td bgcolor="{$notApplicable}"><font size="1">&#160;</font></td>
                <td><font size="1">Not Applicable</font></td>
             </tr>  
         </table>
    </body>
    </HTML>
</xsl:template>




<!-- Add timestamp information -->
<xsl:template match="timestamp">
    <p>
    <table border="0">
        <tr>
            <td><font size="2"><b>This comparison performed:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@date"/>&#9; at &#9;</font></td>
            <td><font size="2"><xsl:value-of select="@time"/></font></td>
        </tr>
    </table>
    </p>
    <xsl:apply-templates/>
</xsl:template>




<!-- Add reference release information -->
<xsl:template match="referenceRelease">
    <table border="0">
        <tr>
            <td><font size="2"><b>Reference Configuration:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@config"/>&#9;</font></td>
            <td><font size="2"><xsl:value-of select="@version"/></font></td>
            <td><font size="2"><xsl:value-of select="@build"/></font></td>
        </tr>
    </table>
    <xsl:apply-templates/>
</xsl:template>




<!-- Add checked release information -->
<xsl:template match="checkedRelease">
         <font size="-1"/>
    <table border="0">
        <tr>
            <td><font size="2"><b>Checked Configuration:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@config"/>&#9;</font></td>
            <td><font size="2"><xsl:value-of select="@version"/></font></td>
            <td><font size="2"><xsl:value-of select="@build"/></font></td>
        </tr>
    </table> 
    <hr/>
    <xsl:apply-templates/>
</xsl:template>


<xsl:template match="summary">
    <table border="0" cellspacing="0">
    <font size="2"><b>Summary</b></font>
    <br/>
    <table>
    <xsl:apply-templates/>
    </table>
    </table>
    <hr/>
</xsl:template>


<xsl:template match="totalBreaks">
    <tr>
        <td><font size="1">Total number of breaks:</font></td>
        <td><font size="1" color="#000099"><xsl:value-of select="@count"/></font></td>
    </tr>
    <xsl:apply-templates/>
</xsl:template>


<xsl:template match="seriousBreaks">
    <tr>
        <td><font size="1">Breaks at level <b><xsl:value-of select="@aboveLevel"/></b> and above:</font></td>
        <td><font size="1" color="#000099"><xsl:value-of select="@count"/></font></td>
    </tr>
    <xsl:apply-templates/>
</xsl:template>


<!--match for a subsystem -->
<xsl:template match="subsystem">
    <br/><b><li/>SUBSYSTEM:&#9;<xsl:value-of select="@name"/></b><br/>
     <xsl:apply-templates/>
</xsl:template>


<xsl:template match="component">
    <b><li/>COMPONENT:&#9;<xsl:value-of select="@name"/></b><br/>
    <xsl:apply-templates/>
</xsl:template>    

<xsl:template match="executable">
    <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
    <xsl:apply-templates/>
</xsl:template>    



<!-- missing headers -->
<xsl:template match="break">
    <xsl:choose>
        <xsl:when test="@type='missingHeader'">
            <b><li/>HEADER FILE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
            <table border="1" cellspacing="0">
            <tr>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
            </tr>
            <TR>
               
                <TD><font size="1" color="{$notApplicable}"><b>Missing Header</b></font></TD>
                <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
            </TR>
            </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='missingExe'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
            <table border="1" cellspacing="0">
            <tr>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
            </tr>
            <TR>
               
                <TD><font size="1" color="{$notApplicable}"><b>Missing Executable</b></font></TD>
                <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
            </TR>
            </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeMMPFileChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got MMP File</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>MMP File Changed</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeDefFileChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected DEF File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got DEF File</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>DEF File Changed</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@mmpfile"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeTargetTypeChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected Target Type</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got Target Type</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>Targettype Changed</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@mmpfile"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='missingClass'">
            <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@header"/>)</font></i><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
                <TR>
                   
                   <xsl:call-template name="formatBreakCell">
                       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
                       <xsl:with-param name="nature"><xsl:value-of select="$classMissing"/></xsl:with-param>
                   </xsl:call-template>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='classAbstractnessChanged'">
            <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@header"/>)</font></i><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
                <TR>
                   
                   <xsl:call-template name="formatBreakCell">
                       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
                       <xsl:with-param name="nature"><xsl:value-of select="$classAbstractnessChanged"/></xsl:with-param>
                   </xsl:call-template>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeUidChanged'">
        	  <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>UID Changed</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeCapabilityAdded'">
        	        	  <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>Capability Added</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
         <xsl:when test="@type='exeCapabilityMissing'">
        	        	  <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                </tr>
                <TR>
                   
                    <TD><font size="1" color="{$notApplicable}"><b>Capability Missing</b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
    </xsl:choose>
</xsl:template>

<xsl:template match="resourceFile">
				<xsl:param name="ac"><xsl:value-of select="@access"/></xsl:param>
				<xsl:param name="st"><xsl:value-of select="@status"/></xsl:param>
				
				<b><li/>RESOURCE FILE:&#9;<xsl:value-of select="@name"/></b><br/>
				<table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
					<td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
					<td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
		<xsl:for-each select="break">
			   <xsl:choose>
        			<xsl:when test="@type='resourceItemChanged'">
					<TR>
	                    <TD><font size="1" color="{$notApplicable}"><b><xsl:value-of select="$resourceItemChanged"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
	                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemNameChanged'">
        				<TR>
		                    <TD><font size="1" color="{$notApplicable}"><b><xsl:value-of select="$resourceItemNameChanged"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemTypeChanged'">
        				<TR>
		                    <TD><font size="1" color="{$notApplicable}"><b><xsl:value-of select="$resourceItemTypeChanged"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        		</xsl:choose>
		</xsl:for-each>
		</table><p/><p/>
</xsl:template>


<!-- deffile template -->
<xsl:template match="deffile">
    <b><li/>DEF FILE:&#9;<xsl:value-of select="@name"/></b><br/>
    <p/>
    <table border="1" cellspacing="0">
        <tr>
            <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
            <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
            <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
            <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        </tr>
        <xsl:for-each select="break">
           	<TR>
              
         	    <TD><font size="1" color="{$notApplicable}"><b>Ordinal Break</b></font></TD>
		        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
        		<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
        	</TR>
        </xsl:for-each>
        </table><p/><p/>
    <xsl:apply-templates/>
</xsl:template>



<!-- class related matches -->
<xsl:template match="class">
    
    <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@file"/>)</font></i><br/>
    <p/>   
    
    <!-- class headings -->
    <table border="1" cellspacing="0">
    <colgroup/>
    <colgroup span="3"/>
    <colgroup span="3" bgcolor="#ffffff"/>
    <colgroup span="2"/>    
    <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>         
    </tr>
 	
    <xsl:for-each select="break">
     		   <TR>
           <xsl:call-template name="formatBreakCell">
               <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
               <xsl:with-param name="nature"><xsl:value-of select="@type"/></xsl:with-param>
           </xsl:call-template>
           <xsl:choose>
                <xsl:when test="@type='vtblItemAdded'">
                	<td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblItemMissing'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='datumAdded'">
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='datumMissing'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classLayoutBreak'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblLayoutChanged'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblOverrideBreak'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='missingEnum'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='anonymousEnumBreak'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:otherwise>
                </xsl:otherwise>
           </xsl:choose>
        </TR>
    </xsl:for-each>
    
    <xsl:for-each select="enum">
             <TR/><TR/>
         <TR>
             <TD colspan="9" bgcolor="#000000" height="5"></TD>
         </TR>
        <TR>
            <xsl:call-template name="formatBreakCell">
               <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
               <xsl:with-param name="nature"><xsl:value-of select="@name"/></xsl:with-param>
               <xsl:with-param name="width">7</xsl:with-param>
            </xsl:call-template>
            
	        <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
	        <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
        </TR>
        <TR>
            <TD colspan="9" bgcolor="#000000" height="5"></TD>
        </TR>
        
        <xsl:for-each select="break">
            <xsl:choose>
                <xsl:when test="@type='addedEnumItem'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueAdded"/></i></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='missingEnumItem'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumMissingValue"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='enumItemNameChanged'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueChangedName"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='enumItemValueChanged'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueChangedValue"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
            </xsl:choose>
        </xsl:for-each>
    </xsl:for-each>
    </table>
    <br/>
    <br/>
 </xsl:template>



<!-- template to handle break cell colouring -->
<xsl:template name="formatBreakCell">
    <xsl:param name="access"/>
    <xsl:param name="nature"/>
     <xsl:param name="width">1</xsl:param>
       <xsl:choose>
            <xsl:when test="@access='N/S'">
                <td colspan="{$width}"><font size="1" color="{$notSpecified}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <xsl:when test="@access='publishedAll'">
                <td colspan="{$width}"><font size="1" color="{$publishedAll}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <xsl:when test="@access='publishedPartner'">
                <td colspan="{$width}"><font size="1" color="{$publishedPartner}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <xsl:when test="@access='internalTechnology'">
                <td colspan="{$width}"><font size="1" color="{$internalTechnology}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <xsl:when test="@access='internalComponent'">
                <td colspan="{$width}"><font size="1" color="{$internalComponent}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <xsl:when test="@access='internalAll'">
                <td colspan="{$width}"><font size="1" color="{$internalAll}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:when>
            <!-- add other switches for api access here -->
               <xsl:otherwise>
                <td><font size="1" color="{$notSpecified}"><b><xsl:value-of select="$nature"/></b></font></td>
            </xsl:otherwise>
        </xsl:choose>
</xsl:template>
    

</xsl:stylesheet>
