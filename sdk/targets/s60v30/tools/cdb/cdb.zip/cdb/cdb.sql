-- The HSQL .sql script to create tables etc.
-- Careful about modifying this - it's actually syntax checked!

--------------------------------------------------
-- table which holds information about releases --
--------------------------------------------------
CREATE CACHED TABLE cdb_releases (
	releaseid integer identity primary key,
	version varchar(32),
	build varchar(8)
);

------------------------------------------------
-- Main table holding all configuration items --
------------------------------------------------
CREATE CACHED TABLE cdb_configitems (
    configid integer identity primary key, 	--The primary key
    releaseid integer,
    name varchar(64) not null, 				-- name of the configuration
    type integer not null, 					--type: user, bldinf, or buildinput, executable
    
    FOREIGN KEY (releaseid) REFERENCES cdb_releases(releaseid)
);

CREATE INDEX cdb_configitems_releaseid ON cdb_configitems(releaseid);


------------------------------------------------------
-- table which maps configurations onto themselves. --
------------------------------------------------------
CREATE CACHED TABLE cdb_configrefs (
    fromid integer not null,  	-- source of mapping
    toid integer not null		-- destination of mapping
);



-----------------------------------------
-- table for holding build input files --
-----------------------------------------
CREATE CACHED TABLE cdb_buildinput (
	buildinputid integer identity primary key,
	configid integer not null,
	name varchar(64) not null,
	location varchar(256) not null,
	
	FOREIGN KEY (configid) REFERENCES cdb_configitems(configid)
);

CREATE INDEX cdb_buildinput_configid ON cdb_buildinput(configid);

-------------------------------------
-- table for storing bldinf files. --
-------------------------------------
CREATE CACHED TABLE cdb_bldinf (
    bldinfid integer identity primary key,			-- always the same as cdb_configuration prim key
	releaseid integer,		-- releases
    location varchar(256) not null, 				-- name and location of file.
    
    FOREIGN KEY (releaseid) REFERENCES cdb_releases(releaseid)
); 


CREATE INDEX cdb_bldinf_releaseid ON cdb_bldinf(releaseid);

----------------------------------------------
-- the set of files exported from a bld.inf --
---------------------------------------------- 
CREATE CACHED TABLE cdb_bldinfexports (
    exportid integer identity primary key, 					-- primary key
    bldinfid integer not null,		-- foreign key
    filefrom varchar(256) not null, 						-- abs source
    fileto varchar(256) not null, 							-- abs destination
    
    FOREIGN KEY (bldinfid) REFERENCES cdb_bldinf(bldinfid)
); 


CREATE INDEX cdb_bldinfexports_bldinfid ON cdb_bldinfexports(bldinfid);


------------------------------
-- the table of executables --
------------------------------
CREATE CACHED TABLE cdb_executables(
    exeid integer identity primary key,						-- primary key
    releaseid integer,										-- releases id.
    targettype varchar(10), -- exe, dll, etc..
    
    mmpfile varchar(256) not null, 							-- name of the mmp file

    deffile varchar(256), 
    validdef bit, -- set if we fail to parse the .def file associated with this .exe.

    
    component varchar(256) not null,					    -- component id
    subsystem varchar(256) not null,						-- id of the subsystem
    
    uida varchar(64),										-- uids of the exe
    uidb varchar(64),
    uidc varchar(64),
    
    capability varchar(256),								-- capabilities of the exe
    
    FOREIGN KEY (releaseid) REFERENCES cdb_releases(releaseid)
); 


CREATE INDEX cdb_executables_releaseid ON cdb_executables(releaseid);



------------------------------------------------
-- Store ordinal data from .def files directly.
CREATE CACHED TABLE cdb_ordinals (
    exeid integer,
    ordinal integer not null, -- the ordinal position
    mangledname varchar(256), 
    unmangledname varchar(256),
    comment varchar(256),
    
    FOREIGN KEY(exeid) REFERENCES cdb_executables(exeid)
); 


CREATE INDEX cdb_ordinals_exeid ON cdb_ordinals(exeid);


--------------------------
-- the extraction queue --
--------------------------
CREATE CACHED TABLE cdb_extractionqueue(
	extractionid integer identity primary key,
	exeid integer,
	configid integer,
	
	FOREIGN KEY (exeid) REFERENCES cdb_executables(exeid),
	FOREIGN KEY (configid) REFERENCES cdb_configitems(configid)
	
);


CREATE INDEX cdb_extractionqueue_exeid ON cdb_extractionqueue(exeid);
CREATE INDEX cdb_extractionqueue_configid ON cdb_extractionqueue(configid);


----------------------
-- components table --
----------------------
CREATE CACHED TABLE cdb_components (
    compid integer identity primary key		-- primary key
); 

----------------------
-- subsystems table --
----------------------
CREATE CACHED TABLE cdb_subsystems (
    subsysid integer identity primary key 	-- primary key
); 

-------------------------------------------------------------------------
-- holds each and every source file that comprises contained executables 
-------------------------------------------------------------------------
CREATE CACHED TABLE cdb_sourcefiles (
    srcfileid integer identity primary key, 
    name varchar(256), 
    epoc32inc varchar(256) -- path relative to \epoc32\include if exported, null otherwise.
); 

CREATE INDEX cdb_sourcefiles_name ON cdb_sourcefiles(name);


-----------------------------------------------------------
CREATE CACHED TABLE cdb_exerelatetype (
    rtid integer identity primary key, 
    name varchar(32), 
    description varchar(256)
); 

INSERT INTO cdb_exerelatetype (name,description) VALUES ('implements', 'The executable implements the API'); 
INSERT INTO cdb_exerelatetype (name,description) VALUES ('client', 'The executable is a client of the API'); 
INSERT INTO cdb_exerelatetype (name,description) VALUES ('unknown', 'The executable uses the API but precise nature of relationship unknown'); 


-----------------------------------------------------------
-- contains a mapping between executables and their source files.
-- we have different kinds of relationships
-----------------------------------------------------------
CREATE CACHED TABLE cdb_exesrc (
    exesrcid integer identity primary key, 
    exeid integer,
    srcid integer, 
    rtid integer,
    FOREIGN KEY(exeid) REFERENCES cdb_executables(exeid),  
    FOREIGN KEY(srcid) REFERENCES cdb_sourcefiles(srcfileid), 
    FOREIGN KEY(rtid) REFERENCES cdb_exerelatetype(rtid)
); 

CREATE INDEX cdb_exesrc_exeid ON cdb_exesrc(exeid);
CREATE INDEX cdb_exesrc_srcid ON cdb_exesrc(srcid);
CREATE INDEX cdb_exesrc_rtid ON cdb_exesrc(rtid);


-- API Classification Access levels
CREATE CACHED TABLE cdb_acaccess (
    acaccessid integer identity primary key, 
    label varchar_ignorecase(32),
    description varchar(256)
);

INSERT INTO cdb_acaccess(label, description) VALUES ('N/S', 'No Classification was specified');
INSERT INTO cdb_acaccess(label, description) VALUES ('publishedAll','');
INSERT INTO cdb_acaccess(label, description) VALUES ('publishedPartner','');
INSERT INTO cdb_acaccess(label, description) VALUES ('internalTechnology','');
INSERT INTO cdb_acaccess(label, description) VALUES ('internalComponent','');
INSERT INTO cdb_acaccess(label, description) VALUES ('internalAll','');

-- do inserts for def

-- API Classification status types
CREATE CACHED TABLE cdb_acstatus (
    acstatusid integer identity primary key, 
    label varchar(32),
    description varchar(256)
    
);

INSERT INTO cdb_acstatus(label, description) VALUES ('N/S', 'No Classification was specified');


---------------------------------------------------------
-- This is the root table for all primary CPP entities, 
-- includes, types, classes, enums, typedefs, namespaces, functions and methods.
-- doesn't include sub-items like base classes etc. 
-- where primary key is shared between all tables
-----------------------------------------------------------
CREATE CACHED TABLE cdb_cppentities( -- should be renamed if storing types too
    cppentityid integer identity primary key, -- class=0, function=1, memberdata=2, enum=3, typedef=4, constant=5(unused), type=6
    srcid integer not null, -- the owning source file. 
    sourceline integer, -- set to -5 for types
    name varchar(512),  
    entitytype integer,
    
    contextid integer, -- used by classes etc..
    qualifiedname varchar(256), -- the qualified name of the function/class/namespace/typedef/enum etc.
    
    initialisable integer,
    
    apiclassaccessid integer,
    apiclassstatusid integer,
    
    FOREIGN KEY(srcid) REFERENCES cdb_sourcefiles(srcfileid),
    FOREIGN KEY(contextid) REFERENCES cdb_cppentities(cppentityid),
    FOREIGN KEY(apiclassaccessid) REFERENCES cdb_acaccess(acaccessid),
    FOREIGN KEY(apiclassstatusid) REFERENCES cdb_acstatus(acstatusid)
    
); 

CREATE INDEX cdb_cppentities_srcid ON cdb_cppentities(srcid);
CREATE INDEX cdb_cppentities_name ON cdb_cppentities(name);
CREATE INDEX cdb_cppentities_contextid ON cdb_cppentities(contextid);
CREATE INDEX cdb_cppentities_entitytype ON cdb_cppentities(entitytype);
CREATE INDEX cdb_cppentities_apiclassaccessid ON cdb_cppentities(apiclassaccessid);
CREATE INDEX cdb_cppentities_apiclassstatusid ON cdb_cppentities(apiclassstatusid);



------------------------------------------
-- Table listing all classes and structs
------------------------------------------
CREATE CACHED TABLE cdb_classes(
    classid integer primary key,
    abstract varchar(64), 
    incomplete varchar(64), 
    access varchar(64), -- 0 = 	private, 1 = protected, 2 - public, -1 = unspecified
    
    FOREIGN KEY(classid) REFERENCES cdb_cppentities(cppentityid)
); 

CREATE INDEX cdb_classes_classid ON cdb_classes(classid);


------------------------------------------
-- Table listing all class and base class pairs. Stores which number base 
-- class it is (for where a class inherits more than one base class).
------------------------------------------
CREATE CACHED TABLE cdb_baseclasses(
    classid integer,
    ordernum integer,
    baseclassid integer,
    FOREIGN KEY(classid) REFERENCES cdb_classes(classid)
); 

CREATE INDEX cdb_baseclasses_classid ON cdb_baseclasses(classid);
CREATE INDEX cdb_baseclasses_baseclassid ON cdb_baseclasses(baseclassid);


----------------------------------------------------
-- Table listing types of type: fundamental, array, reference, pointer and qualified.
-- These types also have a record in the cdb_cppentities table.
-- Note: other types such as classes/typedefs are 
-- cpp_entities but don't have a record in this class.
----------------------------------------------------
CREATE CACHED TABLE cdb_types(
    typeid integer not null primary key, -- all types have this field
    reftype integer, --all types
    basetype integer, -- for pointer to member functions, pointer to data members..
    
    const bit, -- qualified type
    volatile bit, -- qualified type
    
    min integer, -- array type
    max integer, -- array type
    
    FOREIGN KEY(typeid) REFERENCES cdb_cppentities(cppentityid),
    FOREIGN KEY(reftype) REFERENCES cdb_cppentities(cppentityid),
    FOREIGN KEY(basetype) REFERENCES cdb_cppentities(cppentityid)
);


CREATE INDEX cdb_types_reftype ON cdb_types(reftype);
CREATE INDEX cdb_types_basetype ON cdb_types(basetype);


-------------------------------------------------
-- Table listing all functions, including methods
-------------------------------------------------
CREATE CACHED TABLE cdb_functions(
    functionid integer not null primary key,
    
    exportordinal integer, -- null if not exported.
    returntype integer, -- set to -1 for constructors
    
    isoperator bit,
    isellipsis bit, 
    
    position integer, -- the position of the function within its context
    signature varchar(512),
    
    FOREIGN KEY(functionid) REFERENCES cdb_cppentities(cppentityid),
    FOREIGN KEY(returntype) REFERENCES cdb_types(typeid)
    
);


CREATE INDEX cdb_functions_returntype ON cdb_functions(returntype);

--------------------------------------------
-- Table listing all methods
--------------------------------------------
CREATE CACHED TABLE cdb_memberfunctions (
    memfuncid integer not null primary key,  -- not required, can obtain on join with cdb_functions
    access integer, -- public=2/protected=1/private=0
    virtuality integer, -- no=0, yes=1, pure-virtual=2
    isstatic bit, -- is it static...
    vtblpos integer,
    isintroduced bit,
    signature varchar(512),
    isinline integer,
    
    FOREIGN KEY(memfuncid) REFERENCES cdb_functions(functionid)
); 



----------------------------------------------------------------------------------------
-- Table listing all arguments for particular functions, used for type arguments as well...
---------------------------------------------------------------------------------------
CREATE CACHED TABLE cdb_arguments(
    functionid integer,
    name varchar(256),
    typeid integer,
    position integer not null, -- the position of the argument in the declaration
    
    defaultval varchar(256), -- the default value set in func(char* x ="doh") headerrs
    typestring varchar(256),
    
    FOREIGN KEY(functionid) REFERENCES cdb_functions(functionid),
    FOREIGN KEY(typeid) REFERENCES cdb_cppentities(cppentityid)
); 


CREATE INDEX cdb_arguments_functionid ON cdb_arguments(functionid);
CREATE INDEX cdb_arguments_typeid ON cdb_arguments(typeid);



---------------------------------------------
-- Data Members 
---------------------------------------------
CREATE CACHED TABLE cdb_memberdata (
    memdataid integer primary key,
    position integer not null,
    
    typeid integer,
    
    access integer not null, -- public=2/protected=1/private=0/unspecified=-1
    isstatic bit, -- is it static...
    typename varchar(128),
    
    
    
    FOREIGN KEY(memdataid) REFERENCES cdb_cppentities(cppentityid),
    FOREIGN KEY(typeid) REFERENCES cdb_cppentities(cppentityid)
); 

CREATE INDEX cdb_memberdata_typeid ON cdb_memberdata(typeid);


---------------------------------------------
-- Enum vals 
---------------------------------------------
CREATE CACHED TABLE cdb_enumvals (
    enumid integer,
    name varchar(256),
    init integer,
    position integer not null, -- the position of the enum val in the enum
    
    FOREIGN KEY(enumid) REFERENCES cdb_cppentities(cppentityid)
);

CREATE INDEX cdb_enumvals_enumid ON cdb_enumvals(enumid);


----------------------------------------------
-- Breaks
----------------------------------------------
CREATE CACHED TABLE cdb_breaks (
    breakid integer identity primary key,
    subsystem varchar(256),
    component varchar(256),
    breaktype integer,
    class varchar(256),
    file varchar(256),
    position integer,
    expected varchar(256),
    expline integer,
    got varchar(256),
    gotline integer,
    acaccess integer,
    acstatus integer
);

CREATE INDEX cdb_breaks_component ON cdb_breaks(component);
CREATE INDEX cdb_breaks_class ON cdb_breaks(class);
CREATE INDEX cdb_breaks_file ON cdb_breaks(file);
CREATE INDEX cdb_breaks_position ON cdb_breaks(position);


----------------------------------------------
-- Constant member data
----------------------------------------------

CREATE CACHED TABLE cdb_constantdata (
    constdataid integer primary key,

    name varchar(256) not null,
    value varchar(150) not null,
    
    
    FOREIGN KEY(constdataid) REFERENCES cdb_cppentities(cppentityid)
); 


----------------------------------------------
-- Resource file data
----------------------------------------------

CREATE CACHED TABLE cdb_resourcefiles (
    resourcefileid integer identity primary key,
    filename varchar(256) not null
); 

CREATE INDEX cdb_resourcefiles_resourcefileid ON cdb_resourcefiles(resourcefileid);


----------------------------------------------
-- Exe resource data
----------------------------------------------

CREATE CACHED TABLE cdb_exeresource (
    exeid integer,
    resourcefileid integer,

    
    FOREIGN KEY(exeid) REFERENCES cdb_executables(exeid),
    FOREIGN KEY(resourcefileid) REFERENCES cdb_resourcefiles(resourcefileid)
); 

CREATE INDEX cdb_exeresource_exeid ON cdb_exeresource(exeid);
CREATE INDEX cdb_exeresource_resourcefileid ON cdb_exeresource(resourcefileid);

----------------------------------------------
-- Resource types data
----------------------------------------------

CREATE CACHED TABLE cdb_resourcetypes (
    resourcetypeid integer identity primary key,
   type varchar(256) not null

); 


----------------------------------------------
-- Resource data
----------------------------------------------

CREATE CACHED TABLE cdb_resources (
    resourceid integer identity primary key,
    resourcefileid integer not null,
    position integer,
    typeid integer not null,
    name varchar(256),
    contextid integer,
    qualifiedname varchar(256),
    
    FOREIGN KEY(resourcefileid) REFERENCES cdb_resourcefiles(resourcefileid),
    FOREIGN KEY(typeid) REFERENCES cdb_resourcetypes(resourcetypeid)
);
