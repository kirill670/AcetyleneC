/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Charge.
 * The measurement Unit for this quantity is the Coulomb (Ampere * Second = A*s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #COULOMB
 * @see     ElectricCurrent#AMPERE
 * @see     Duration#SECOND
 */
public final class ElectricCharge extends Quantity {

  /**
   * This class represents Units of ElectricCharge.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toCoulomb;

    private Unit() { // Default Unit (Coulomb)
      super(ElectricCurrent.AMPERE.multiply(Duration.SECOND));
      this.toCoulomb = 1.0;
    }

    /**
      * Constructs a fundamental Unit of ElectricCharge.
      *
      * @param   symbol the symbol of this Unit
      * @param   toCoulomb the multiplier coefficient to convert this
      *          Unit to Coulomb
      * @see     ElectricCharge#COULOMB
      */
    public Unit(String symbol, double toCoulomb) {
      super(symbol);
      this.toCoulomb = toCoulomb;
    }
  }

  /**
   * Used to specify Coulomb Unit. One Coulomb is equal to the
   * quantity of charge transferred in one second by a steady current of one ampere.
   * It is named after the French physicist Charles Augustin de Coulomb (1736-1806).
   */
  public static final Unit COULOMB = new Unit();

  /**
   * Used to specify e Unit. It is equal to the charge on one electron.
   */
  public static final Unit E = new Unit("e", 160.217733e-21);

  /**
   * Used to specify Faraday Unit.
   */
  public static final Unit FARADAY = new Unit("Faraday",
          (new ElectricCharge(1.0, E).doubleValue()) /
          (new AmountOfSubstance(1.0,
          AmountOfSubstance.ONE).doubleValue()));

  /**
   * Used to specify Franklin Unit.
   */
  public static final Unit FRANKLIN = new Unit("Franklin", 3.3356e-10);

  /**
   * Constructs an ElectricCharge in Coulomb from the specified electric charge
   * stated using the specified Unit.
   *
   * @param   value the electric charge stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricCharge(double value, Unit unit) {
    super(value * unit.toCoulomb,
          COULOMB);
  }

  /**
   * Constructs an ElectricCharge in Coulomb from the specified electric charge
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric charge stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricCharge(double value, double error, Unit unit) {
    super(value * unit.toCoulomb,
          error * unit.toCoulomb,
          COULOMB);
  }

  /**
   * Translates a Quantity in Coulomb to ElectricCharge.
   *
   * @param   q the quantity in Coulomb
   * @throws  UnitException quantity is not in A*s
   */
  public ElectricCharge(Quantity q) {
    super(q);
    if (!q.unit.equals(COULOMB))
      throw new UnitException("Quantity is not in A*s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in A*s
   */
  public ElectricCharge(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(COULOMB))
      throw new UnitException("Quantity is not in A*s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricCharge in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toCoulomb,
                        this.absoluteError() / unit.toCoulomb,
                        unit);
  }

  /**
   * Sets the value for this ElectricCharge stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricCharge stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toCoulomb);
  }

  /**
   * Sets the value and the measurement error for this ElectricCharge both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricCharge stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toCoulomb,
        error * unit.toCoulomb);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

