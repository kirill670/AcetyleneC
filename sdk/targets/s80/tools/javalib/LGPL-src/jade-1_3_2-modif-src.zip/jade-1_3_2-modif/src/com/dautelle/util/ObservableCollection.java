/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;
import java.util.Collection;

/**
 * This interface enables collections to notify listeners when elements are
 * added or removed.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     CollectionEvent
 * @see     CollectionListener
 */
public interface ObservableCollection extends Collection {

  /**
   * Adds the specified listener to receive collection events from this
   * collection.
   *
   * @param l the listener.
   */
  public void addCollectionListener(CollectionListener l);


  /**
   * Removes the specified listener so it no longer receives events from
   * this collection.
   *
   * @param l the listener.
   */
  public void removeCollectionListener(CollectionListener l);

}