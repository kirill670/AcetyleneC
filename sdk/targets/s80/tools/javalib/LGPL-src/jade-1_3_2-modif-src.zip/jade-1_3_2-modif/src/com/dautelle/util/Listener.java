/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;
import java.util.EventListener;

/**
 * The listener interface for receiving basic object events.
 * The class that is interested in processing an <code>Event</code>
 * implements this interface, and the object created with that class is
 * registered with an <code>Observable</code> object, using the Observable's
 * <code>addListener</code> method.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     Observable
 * @see     Event
 */
public interface Listener extends EventListener {

  /**
   * Invoked when the state of the Observable has changed.
   *
   * @param e the source event.
   */
  public void stateChanged(Event e);

  /**
   * Invoked when the Observable is to be deleted.
   *
   * @param e the source event.
   */
  public void toBeDeleted(Event e);

}