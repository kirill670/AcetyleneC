/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Conductance.
 * The measurement Unit for this quantity is the Siemens
 * (1 / Ohm = A*A*s*s*s/kg/m/m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #SIEMENS
 * @see     ElectricResistance#OHM
 */
public final class ElectricConductance extends Quantity {

  /**
   * This class represents Units of ElectricConductance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toSiemens;

    private Unit() { // Default Unit (Siemens)
      super(ElectricResistance.OHM.inverse());
      this.toSiemens = 1.0;
    }

    /**
      * Constructs a fundamental Unit of ElectricConductance.
      *
      * @param   symbol the symbol of this Unit
      * @param   toSiemens the multiplier coefficient to convert this
      *          Unit to Siemens
      * @see     ElectricConductance#SIEMENS
      */
    public Unit(String symbol, double toSiemens) {
      super(symbol);
      this.toSiemens = toSiemens;
    }
  }

  /**
   * Used to specify Siemens Unit. One Siemens is equal to one ampere per
   * volt.
   * It is named after the German engineer Ernst Werner von Siemens (1816-1892).
   */
  public static final Unit SIEMENS = new Unit();

  /**
   * Used to specify Mho Unit.
   */
  public static final Unit MHO = new Unit("Mho", 1);

  /**
   * Constructs an ElectricConductance in Siemens from the specified electric conductance
   * stated using the specified Unit.
   *
   * @param   value the electric conductance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricConductance(double value, Unit unit) {
    super(value * unit.toSiemens,
          SIEMENS);
  }

  /**
   * Constructs an ElectricConductance in Siemens from the specified electric conductance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric conductance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricConductance(double value, double error, Unit unit) {
    super(value * unit.toSiemens,
          error * unit.toSiemens,
          SIEMENS);
  }

  /**
   * Translates a Quantity in Siemens to ElectricConductance.
   *
   * @param   q the quantity in Siemens
   * @throws  UnitException quantity is not in A*A*s*s*s/kg/m/m
   */
  public ElectricConductance(Quantity q) {
    super(q);
    if (!q.unit.equals(SIEMENS))
      throw new UnitException(
              "Quantity is not in A*A*s*s*s/kg/m/m but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in A*A*s*s*s/kg/m/m
   */
  public ElectricConductance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(SIEMENS))
      throw new UnitException(
              "Quantity is not in A*A*s*s*s/kg/m/m but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricConductance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toSiemens,
                        this.absoluteError() / unit.toSiemens,
                        unit);
  }

  /**
   * Sets the value for this ElectricConductance stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricConductance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toSiemens);
  }

  /**
   * Sets the value and the measurement error for this ElectricConductance both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricConductance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toSiemens,
        error * unit.toSiemens);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

