/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a Magnetic Flux Density.
 * The measurement Unit for this quantity is the Tesla
 * (Volt * Second / Square_Meter = kg/A/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #TESLA
 * @see     ElectricPotential#VOLT
 * @see     Duration#SECOND
 * @see     Area#SQUARE_METER
 */
public final class MagneticFluxDensity extends Quantity {

  /**
   * This class represents Units of MagneticFluxDensity.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toTesla;

    private Unit() { // Default Unit (Tesla)
      super(ElectricPotential.VOLT.multiply(Duration.SECOND).divide(
              Area.SQUARE_METER));
      this.toTesla = 1.0;
    }

    /**
     * Constructs a fundamental Unit of MagneticFluxDensity.
     *
     * @param   symbol the symbol of this Unit
     * @param   toTesla the multiplier coefficient to convert this
     *          Unit to Tesla
     * @see     MagneticFluxDensity#TESLA
     */
    public Unit(String symbol, double toTesla) {
      super(symbol);
      this.toTesla = toTesla;
    }
  }

  /**
   * Used to specify Tesla Unit. One Tesla is equal equal to one weber per square meter.
   * It is named after the Serbian-born American electrical engineer and physicist
   * Nikola Tesla (1856-1943).
   */
  public static final Unit TESLA = new Unit();

  /**
   * Used to specify Gauss Unit.
   */
  public static final Unit GAUSS = new Unit("Gauss", 1e-4); // Exact.

  /**
   * Constructs a MagneticFluxDensity in Tesla from the specified magnetic flux density
   * stated using the specified Unit.
   *
   * @param   value the magnetic flux density stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public MagneticFluxDensity(double value, Unit unit) {
    super(value * unit.toTesla,
          TESLA);
  }

  /**
   * Constructs a MagneticFluxDensity in Tesla from the specified magnetic flux density
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the magnetic flux density stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public MagneticFluxDensity(double value, double error, Unit unit) {
    super(value * unit.toTesla,
          error * unit.toTesla,
          TESLA);
  }

  /**
   * Translates a Quantity in Tesla to MagneticFluxDensity.
   *
   * @param   q the quantity in Tesla
   * @throws  UnitException quantity is not in kg/A/s/s
   */
  public MagneticFluxDensity(Quantity q) {
    super(q);
    if (!q.unit.equals(TESLA))
      throw new UnitException("Quantity is not in kg/A/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg/A/s/s
   */
  public MagneticFluxDensity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(TESLA))
      throw new UnitException("Quantity is not in kg/A/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this MagneticFluxDensity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toTesla,
                        this.absoluteError() / unit.toTesla,
                        unit);
  }

  /**
   * Sets the value for this MagneticFluxDensity stated using the specified
   * measurement Unit.
   *
   * @param   value the MagneticFluxDensity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toTesla);
  }

  /**
   * Sets the value and the measurement error for this MagneticFluxDensity both
   * stated using the specified measurement Unit.
   *
   * @param   value the MagneticFluxDensity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toTesla,
        error * unit.toTesla);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}