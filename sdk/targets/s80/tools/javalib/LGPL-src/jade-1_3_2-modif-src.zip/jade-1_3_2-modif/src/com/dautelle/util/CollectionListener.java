/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.util;

/**
 * The listener interface for receiving collection events.
 * The class that is interested in processing a <code>CollectionEvent</code>
 * implements this interface, and the object created with that class is
 * registered with an <code>ObservableCollection</code> object,
 * using the ObservableCollection's <code>addCollectionListener</code> method.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     ObservableCollection
 * @see     CollectionEvent
 */
public interface CollectionListener extends Listener {

  /**
   * Invoked when an element is added to the ObservableCollection.
   *
   * @param e the collection event.
   */
  public void elementAdded(CollectionEvent e);

  /**
   * Invoked when an element is removed from the ObservableCollection.
   *
   * @param e the collection event.
   */
  public void elementRemoved(CollectionEvent e);

}