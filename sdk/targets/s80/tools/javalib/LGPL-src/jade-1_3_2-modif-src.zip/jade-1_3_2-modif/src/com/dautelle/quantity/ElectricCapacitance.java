/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Electric Capacitance.
 * The measurement Unit for this quantity is the Farad
 * (Coulomb / Volt = A*A*s*s*s*s/kg/m/m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #FARAD
 * @see     ElectricCharge#COULOMB
 * @see     ElectricPotential#VOLT
 */
public final class ElectricCapacitance extends Quantity {

  /**
   * This class represents Units of ElectricCapacitance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toFarad;

    private Unit() { // Default Unit (Farad)
      super(ElectricCharge.COULOMB.divide(ElectricPotential.VOLT));
      this.toFarad = 1.0;
    }

    /**
      * Constructs a fundamental Unit of ElectricCapacitance.
      *
      * @param   symbol the symbol of this Unit
      * @param   toFarad the multiplier coefficient to convert this
      *          Unit to Farad
      * @see     ElectricCapacitance#FARAD
      */
    public Unit(String symbol, double toFarad) {
      super(symbol);
      this.toFarad = toFarad;
    }
  }

  /**
   * Used to specify Farad Unit. One Farad is equal to the capacitance
   * of a capacitor having an equal and opposite charge of 1 coulomb
   * on each plate and a potential difference of 1 volt between the plates.
   * It is named after the British physicist and chemist Michael Faraday
   * (1791-1867).
   */
  public static final Unit FARAD = new Unit();

  /**
   * Constructs an ElectricCapacitance in Farad from the specified electric capacitance
   * stated using the specified Unit.
   *
   * @param   value the electric capacitance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public ElectricCapacitance(double value, Unit unit) {
    super(value * unit.toFarad,
          FARAD);
  }

  /**
   * Constructs an ElectricCapacitance in Farad from the specified electric capacitance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the electric capacitance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public ElectricCapacitance(double value, double error, Unit unit) {
    super(value * unit.toFarad,
          error * unit.toFarad,
          FARAD);
  }

  /**
   * Translates a Quantity in Farad to ElectricCapacitance.
   *
   * @param   q the quantity in Farad
   * @throws  UnitException quantity is not in A*A*s*s*s*s/kg/m/m
   */
  public ElectricCapacitance(Quantity q) {
    super(q);
    if (!q.unit.equals(FARAD))
      throw new UnitException(
              "Quantity is not in A*A*s*s*s*s/kg/m/m but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in A*A*s*s*s*s/kg/m/m
   */
  public ElectricCapacitance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(FARAD))
      throw new UnitException(
              "Quantity is not in A*A*s*s*s*s/kg/m/m but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this ElectricCapacitance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toFarad,
                        this.absoluteError() / unit.toFarad,
                        unit);
  }

  /**
   * Sets the value for this ElectricCapacitance stated using the specified
   * measurement Unit.
   *
   * @param   value the ElectricCapacitance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toFarad);
  }

  /**
   * Sets the value and the measurement error for this ElectricCapacitance both
   * stated using the specified measurement Unit.
   *
   * @param   value the ElectricCapacitance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toFarad,
        error * unit.toFarad);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

