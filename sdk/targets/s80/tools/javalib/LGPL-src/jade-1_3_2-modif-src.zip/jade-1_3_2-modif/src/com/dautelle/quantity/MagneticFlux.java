/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a Magnetic Flux.
 * The measurement Unit for this quantity is the Weber
 * (Volt * Second  = kg*m*m/A/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #WEBER
 * @see     ElectricPotential#VOLT
 * @see     Duration#SECOND
 */
public final class MagneticFlux extends Quantity {

  /**
   * This class represents Units of MagneticFlux.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toWeber;

    private Unit() { // Default Unit (Weber)
      super(ElectricPotential.VOLT.multiply(Duration.SECOND));
      this.toWeber = 1.0;
    }

    /**
     * Constructs a fundamental Unit of MagneticFlux.
     *
     * @param   symbol the symbol of this Unit
     * @param   toWeber the multiplier coefficient to convert this
     *          Unit to Weber
     * @see     MagneticFlux#WEBER
     */
    public Unit(String symbol, double toWeber) {
      super(symbol);
      this.toWeber = toWeber;
    }
  }

  /**
   * Used to specify Weber Unit. One Weber is equal to the magnetic flux
   * that in linking a circuit of one turn produces in it an electromotive
   * force of one volt as it is uniformly reduced to zero within one second.
   * It is named after the German physicist Wilhelm Eduard Weber (1804-1891).
   */
  public static final Unit WEBER = new Unit();

  /**
   * Used to specify Maxwell Unit.
   */
  public static final Unit MAXWELL = new Unit("Maxwell", 1e-8); // Exact.

  /**
   * Constructs a MagneticFlux in Weber from the specified magnetic flux
   * stated using the specified Unit.
   *
   * @param   value the magnetic flux stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public MagneticFlux(double value, Unit unit) {
    super(value * unit.toWeber,
          WEBER);
  }

  /**
   * Constructs a MagneticFlux in Weber from the specified magnetic flux
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the magnetic flux stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public MagneticFlux(double value, double error, Unit unit) {
    super(value * unit.toWeber,
          error * unit.toWeber,
          WEBER);
  }

  /**
   * Translates a Quantity in Weber to MagneticFlux.
   *
   * @param   q the quantity in Weber
   * @throws  UnitException quantity is not in kg*m*m/A/s/s
   */
  public MagneticFlux(Quantity q) {
    super(q);
    if (!q.unit.equals(WEBER))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/s/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in kg*m*m/A/s/s
   */
  public MagneticFlux(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(WEBER))
      throw new UnitException(
              "Quantity is not in kg*m*m/A/s/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this MagneticFlux in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toWeber,
                        this.absoluteError() / unit.toWeber,
                        unit);
  }

  /**
   * Sets the value for this MagneticFlux stated using the specified
   * measurement Unit.
   *
   * @param   value the MagneticFlux stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toWeber);
  }

  /**
   * Sets the value and the measurement error for this MagneticFlux both
   * stated using the specified measurement Unit.
   *
   * @param   value the MagneticFlux stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toWeber,
        error * unit.toWeber);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}