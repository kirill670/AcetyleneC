/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents a Radioactive Activity.
 * The measurement Unit for this quantity is the Becquerel (1 / Second = 1/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #BECQUEREL
 * @see     Duration#SECOND
 */
public final class RadioactiveActivity extends Quantity {

  /**
   * This class represents Units of RadioactiveActivity.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toBecquerel;

    private Unit() { // Default Unit (Becquerel)
      super(Duration.SECOND.inverse());
      this.toBecquerel = 1.0;
    }

    /**
     * Constructs a fundamental Unit of RadioactiveActivity.
     *
     * @param   symbol the symbol of this Unit
     * @param   toBecquerel the multiplier coefficient to convert this
     *          Unit to Becquerel
     * @see     #BECQUEREL
     */
    public Unit(String symbol, double toBecquerel) {
      super(symbol);
      this.toBecquerel = toBecquerel;
    }
  }

  /**
   * Used to specify Becquerel Unit. One becquerel is the radiation caused
   * by one disintegration per second.
   * It is named after the French physicist, Antoine-Henri Becquerel (1852-1908).
   */
  public static final Unit BECQUEREL = new Unit();

  /**
   * Used to specify Curie Unit.
   */
  public static final Unit CURIE = new Unit("Curie", 3.7e10);

  /**
   * Used to specify Rutherford Unit.
   */
  public static final Unit RUTHERFORD = new Unit("Rutherford", 1e6);

  /**
   * Constructs a RadioactiveActivity in Becquerel from the specified radioactive activity
   * stated using the specified Unit.
   *
   * @param   value the radioactive activity stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public RadioactiveActivity(double value, Unit unit) {
    super(value * unit.toBecquerel,
          BECQUEREL);
  }

  /**
   * Constructs a RadioactiveActivity in Becquerel from the specified radioactive activity
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the radioactive activity stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public RadioactiveActivity(double value, double error, Unit unit) {
    super(value * unit.toBecquerel,
          error * unit.toBecquerel,
          BECQUEREL);
  }

  /**
   * Translates a Quantity in Becquerel to a RadioactiveActivity.
   *
   * @param   q the quantity in Becquerel
   * @throws  UnitException quantity is not in 1/s
   */
  public RadioactiveActivity(Quantity q) {
    super(q);
    if (!q.unit.equals(BECQUEREL))
      throw new UnitException("Quantity is not in 1/s but in " + q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in 1/s
   */
  public RadioactiveActivity(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(BECQUEREL))
      throw new UnitException("Quantity is not in 1/s but in " + this.unit);
  }

  /**
   * Returns a Quantity corresponding to this RadioactiveActivity in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toBecquerel,
                        this.absoluteError() / unit.toBecquerel,
                        unit);
  }

  /**
   * Sets the value for this RadioactiveActivity stated using the specified
   * measurement Unit.
   *
   * @param   value the RadioactiveActivity stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toBecquerel);
  }

  /**
   * Sets the value and the measurement error for this RadioactiveActivity both
   * stated using the specified measurement Unit.
   *
   * @param   value the RadioactiveActivity stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toBecquerel,
        error * unit.toBecquerel);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}