rem This file was modified by Symbian on 19 April 2001.
rem This file was modified by Symbian on 13 June 2001.

rem ########
rem Clean-up
rem ########
rmdir /S/Q bin
mkdir bin
rmdir /S/Q doc
mkdir doc
del lib\jade.jar

rem #####################
rem Create source archive
rem #####################
cd ..
%java_home%\bin\jar -cvfM jade-1_3_2-modif\jade.zip jade-1_3_2-modif\src\*.java jade-1_3_2-modif\src\com\dautelle\html\*.java jade-1_3_2-modif\src\com\dautelle\math\*.java jade-1_3_2-modif\src\com\dautelle\quantity\*.java jade-1_3_2-modif\src\com\dautelle\util\*.java jade-1_3_2-modif\src\com\dautelle\xml\*.java jade-1_3_2-modif\res\*.jpg jade-1_3_2-modif\web\*.html jade-1_3_2-modif\web\*.jpg jade-1_3_2-modif\web\*.xml jade-1_3_2-modif\web\*.gif jade-1_3_2-modif\version.txt jade-1_3_2-modif\make.bat jade-1_3_2-modif\readme-1.3.2-modif.txt
cd jade-1_3_2-modif

rem ##############
rem Copy resources
rem ##############
copy res\*.jpg bin

rem #######
rem Compile
rem #######
%java_home%\bin\javac -g:none -O -sourcepath src -classpath bin;lib\jaxp1.1\jaxp.jar;lib\jaxp1.1\crimson.jar;lib\jaxp1.1\xalan.jar -d bin src\*.java src\com\dautelle\util\*.java src\com\dautelle\math\*.java src\com\dautelle\quantity\*.java src\com\dautelle\xml\*.java src\com\dautelle\html\*.java

rem ###################
rem Build documentation
rem ###################
%java_home%\bin\javadoc -sourcepath src -classpath bin;lib\jaxp1.1\jaxp.jar;lib\jaxp1.1\crimson.jar;lib\jaxp1.1\xalan.jar -d doc com.dautelle.util com.dautelle.math com.dautelle.quantity com.dautelle.xml       com.dautelle.html

rem #############
rem Build library
rem #############
%java_home%\bin\jar -cvfm lib\jade.jar version.txt -C bin .
