/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents an Illuminance.
 * The measurement Unit for this quantity is the Lux
 * (Lumen / Square_Meter = cd*sr/m/m).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #LUX
 * @see     LuminousFlux#LUMEN
 * @see     Area#SQUARE_METER
 */
public final class Illuminance extends Quantity {

  /**
   * This class represents Units of Illuminance.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toLux;

    private Unit() { // Default Unit (Lux)
      super(LuminousFlux.LUMEN.divide(Area.SQUARE_METER));
      this.toLux = 1.0;
    }

    /**
      * Constructs a fundamental Unit of Illuminance.
      *
      * @param   symbol the symbol of this Unit
      * @param   toLux the multiplier coefficient to convert this
      *          Unit to Lux
      * @see     #LUX
      */
    public Unit(String symbol, double toLux) {
      super(symbol);
      this.toLux = toLux;
    }
  }

  /**
   * Used to specify Lux Unit. One Lux is equal to one lumen per square meter.
   */
  public static final Unit LUX = new Unit();

  /**
   * Used to specify Lambert Unit.
   */
  public static final Unit LAMBERT = new Unit("Lambert", 1e4); // Exact.

  /**
   * Constructs an Illuminance in Lux from the specified illuminance
   * stated using the specified Unit.
   *
   * @param   value the illuminance stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public Illuminance(double value, Unit unit) {
    super(value * unit.toLux,
          LUX);
  }

  /**
   * Constructs an Illuminance in Lux from the specified illuminance
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the illuminance stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public Illuminance(double value, double error, Unit unit) {
    super(value * unit.toLux,
          error * unit.toLux,
          LUX);
  }

  /**
   * Translates a Quantity in Lux to Illuminance.
   *
   * @param   q the quantity in Lux
   * @throws  UnitException quantity is not in cd*sr/m/m
   */
  public Illuminance(Quantity q) {
    super(q);
    if (!q.unit.equals(LUX))
      throw new UnitException("Quantity is not in cd*sr/m/m but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in cd*sr/m/m
   */
  public Illuminance(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(LUX))
      throw new UnitException("Quantity is not in cd*sr/m/m but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this Illuminance in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toLux,
                        this.absoluteError() / unit.toLux,
                        unit);
  }

  /**
   * Sets the value for this Illuminance stated using the specified
   * measurement Unit.
   *
   * @param   value the Illuminance stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toLux);
  }

  /**
   * Sets the value and the measurement error for this Illuminance both
   * stated using the specified measurement Unit.
   *
   * @param   value the Illuminance stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toLux,
        error * unit.toLux);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}

