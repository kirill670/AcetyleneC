/**
 * J.A.D.E.  Java(TM) Addition to Default Environment.
 * Copyright (C) 2000 Jean-Marie Dautelle
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Latest release available at http://jade.dautelle.com/
 */
package com.dautelle.quantity;
import com.dautelle.xml.*;

/**
 * This class represents the effective (or "equivalent") dose of radiation
 * received by a human or some other living organism.
 * The measurement Unit for this quantity is the Sievert
 * (Joule / Kilogram = m*m/s/s).
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 1.3, February 24, 2001
 * @see     #SIEVERT
 * @see     Energy#JOULE
 * @see     Mass#KILOGRAM
 */
public final class RadiationDoseEffective extends Quantity {

  /**
   * This class represents Units of RadiationDoseEffective.
   */
  public final static class Unit extends com.dautelle.quantity.Unit {
    private final double toSievert;

    private Unit() { // Default Unit (Sievert)
      super(Energy.JOULE.divide(Mass.KILOGRAM));
      this.toSievert = 1.0;
    }

    /**
     * Constructs a fundamental Unit of RadiationDoseEffective.
     *
     * @param   symbol the symbol of this Unit
     * @param   toSievert the multiplier coefficient to convert this
     *          Unit to Sievert
     * @see     #SIEVERT
     */
    public Unit(String symbol, double toSievert) {
      super(symbol);
      this.toSievert = toSievert;
    }
  }

  /**
   * Used to specify Sievert Unit. One Sievert is equal  is equal to the
   * actual dose, in grays, multiplied by a "quality factor" which is larger
   * for more dangerous forms of radiation.
   * It is named after the Swedish physicist Rolf Sievert (1898-1966).
   */
  public static final Unit SIEVERT = new Unit();

  /**
   * Used to specify Rem Unit.
   */
  public static final Unit REM = new Unit("Rem", 0.01); // Exact.

  /**
   * Constructs a RadiationDoseEffective in Sievert from the specified radiation dose
   * stated using the specified Unit.
   *
   * @param   value the radiation dose stated using the specified Unit
   * @param   unit the measurement Unit
   */
  public RadiationDoseEffective(double value, Unit unit) {
    super(value * unit.toSievert,
          SIEVERT);
  }

  /**
   * Constructs a RadiationDoseEffective in Sievert from the specified radiation dose
   * and the specified built-in error, both stated using the specified Unit.
   *
   * @param   value the radiation dose stated using the specified Unit
   * @param   error the absolute error
   * @param   unit the measurement Unit
   */
  public RadiationDoseEffective(double value, double error, Unit unit) {
    super(value * unit.toSievert,
          error * unit.toSievert,
          SIEVERT);
  }

  /**
   * Translates a Quantity in Sievert to a RadiationDoseEffective.
   *
   * @param   q the quantity in Sievert
   * @throws  UnitException quantity is not in m*m/s/s
   */
  public RadiationDoseEffective(Quantity q) {
    super(q);
    if (!q.unit.equals(SIEVERT))
      throw new UnitException("Quantity is not in m*m/s/s but in " +
              q.unit);
  }

  /**
   * XML Constructor.
   *
   * @param  attributes the 'value', 'error' and 'unit' attributes
   *         of this Quantity.
   * @param  content (none).
   * @throws  UnitException quantity is not in m*m/s/s
   */
  public RadiationDoseEffective(Attributes attributes, Elements content) {
    super(attributes.getDouble("value"), attributes.getDouble("error"),
          Unit.parse(attributes.get("unit")));
    if (!this.unit.equals(SIEVERT))
      throw new UnitException("Quantity is not in m*m/s/s but in " +
              this.unit);
  }

  /**
   * Returns a Quantity corresponding to this RadiationDoseEffective in the specified Unit.
   *
   * @param   unit the Quantity Unit
   */
  public Quantity in(Unit unit) {
    return new Quantity(this.doubleValue() / unit.toSievert,
                        this.absoluteError() / unit.toSievert,
                        unit);
  }

  /**
   * Sets the value for this RadiationDoseEffective stated using the specified
   * measurement Unit.
   *
   * @param   value the RadiationDoseEffective stated using the specified Unit.
   * @param   unit the measurement Unit.
   */
  public void set(double value, Unit unit) {
    set(value * unit.toSievert);
  }

  /**
   * Sets the value and the measurement error for this RadiationDoseEffective both
   * stated using the specified measurement Unit.
   *
   * @param   value the RadiationDoseEffective stated using the specified Unit.
   * @param   error the absolute error.
   * @param   unit the measurement Unit.
   * @throws  IllegalArgumentException the absolute error is always positive.
   */
  public void set(double value, double error, Unit unit) {
    set(value * unit.toSievert,
        error * unit.toSievert);
  }

  // Specific constructors.
  //


  // Specific methods.
  //
}