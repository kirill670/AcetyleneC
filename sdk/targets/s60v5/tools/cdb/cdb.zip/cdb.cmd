@echo off
rem cdb.pl launcher.
rem uses perl to find location of the bin directory, and env variables etc.
perl -S cdb.pl %*
