#!perl
# Copyright (c) 2004 Symbian Ltd. All rights reserved.
# Execute CDB, but find its location, and get epocroot first. 

use strict;
use warnings;
use FindBin qw($Bin);

(my $toolsdir=$Bin)=~s@/@\\@g;
my $epocroot = $ENV{EPOCROOT};

# configure the Jet VM 
# Including rt.jar includes required XML files for XSL transformation. 
# should update, so if a -j option is specified, it uses a native java version...that way we can unify everything.

$ENV{JETVMPROP}="-Djet.gc.heaplimit:1100M -Djet.gc.defragment -Djava.class.path:$toolsdir\\cdb\\rt.jar";
system "$toolsdir\\cdb\\cdb.exe -e $epocroot @ARGV\n";
