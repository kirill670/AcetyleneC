<?xml version="1.0"  encoding="ISO-8859-1"?>
<xsl:stylesheet 
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
    version="1.0"
    > 
    <xsl:output method="html"/> 

<xsl:key name="access-lookup" match="access" use="id"/>
 <xsl:variable name="write_access_color" select="document('access.xml')/userdefined"/>

<!-- break descriptions -->
<xsl:param name="inlineFunctionMissing">Inline Function Missing</xsl:param>
<xsl:param name="inlineFunctionSignatureChanged">Inline Function Signature Changed</xsl:param>

<xsl:param name="vtblItemAdded">Vtbl Item Added</xsl:param>
<xsl:param name="vtblItemMissing">Vtbl Item Missing</xsl:param>
<xsl:param name="vtblLayoutChanged">Vtbl Layout Changed</xsl:param>
<xsl:param name="vtblOverrideChanged">Vtbl Override Changed</xsl:param>

<xsl:param name="classMissing">Class Missing</xsl:param>
<xsl:param name="classDatumAdded">Class Datum Added</xsl:param>
<xsl:param name="classDatumMissing">Class Datum Missing</xsl:param>
<xsl:param name="classLayoutChanged">Class Layout Changed</xsl:param>
<xsl:param name="classSizeChanged">Class Size Changed</xsl:param>
<xsl:param name="classAbstractnessChanged">Class Abstractness Changed</xsl:param>
<xsl:param name="classSizeChangedMemberData">Class Size Changed Member Data</xsl:param>
<xsl:param name="classSizeChangedVtableAdded">Class Size Changed Vtable Added</xsl:param>
<xsl:param name="classSizeChangedVtableRemoved">Class Size Changed Vtable Removed</xsl:param>

<xsl:param name="classificationTightened">Entity Classification Tightened</xsl:param>
<xsl:param name="classificationBroken">Entity Classification Broken</xsl:param>
<xsl:param name="classificationRemoved">Entity Classification Removed</xsl:param>
<xsl:param name="classificationSlightlyTightened">Entity Classification Slightly Tightened</xsl:param>

<xsl:param name="enumMissing">Enum Missing</xsl:param>
<xsl:param name="enumMissingValue">Enum Entry Missing</xsl:param>
<xsl:param name="enumValueAdded">Enum Entry Added</xsl:param>
<xsl:param name="enumValueChangedValue">Enum Entry Changed Value</xsl:param>
<xsl:param name="enumValueChangedName">Enum Entry Changed Name</xsl:param>
<xsl:param name="enumAnonymousBreak">Anonymous Enum Break</xsl:param>

<xsl:param name="constMissing">Const Missing</xsl:param>
<xsl:param name="constValueChanged">Const Entry Changed</xsl:param>

<xsl:param name="ordinalAbsent">Ordinal Absent</xsl:param>
<xsl:param name="ordinalItemMissing">Ordinal Item Missing</xsl:param>
<xsl:param name="ordinalLayoutChanged">Ordinal Layout Changed</xsl:param>
<xsl:param name="ordinalRipple">Ordinal Ripple</xsl:param>

<xsl:param name="missingExe">Exe Missing</xsl:param>
<xsl:param name="exeTargetTypeChanged">Exe Targettype Changed</xsl:param>
<xsl:param name="exeDefFileChanged">Exe DEF File Changed</xsl:param>
<xsl:param name="exeMMPFileChanged">Exe MMP File Changed</xsl:param>
<xsl:param name="exeUIDChanged">Exe UID Changed</xsl:param>
<xsl:param name="exeCapabilityChanged">Exe Capability Changed</xsl:param>

<xsl:param name="missingHeader">Header Missing</xsl:param>

<xsl:param name="resourceFileMissing">Resource File Missing</xsl:param>
<xsl:param name="resourceItemChanged">Resource Item Changed</xsl:param>
<xsl:param name="resourceItemMissing">Resource Item Missing</xsl:param>
<xsl:param name="resourceItemNameChanged">Resource Item Name Changed</xsl:param>
<xsl:param name="resourceItemTypeChanged">Resource Item Type Changed</xsl:param>
<xsl:param name="resourceItemImpacted">Resource Item Impacted</xsl:param>
<xsl:param name="resourceOrderChanged">Resource Order Changed</xsl:param>
<xsl:param name="resourceItemAdded">Resource Item Added</xsl:param>

<!-- global template match -->    
<xsl:template match="/">
    <xsl:apply-templates/>
</xsl:template>



<!-- This is used for the overall report-->
<xsl:template match="compatibilityReport">
    <HTML>
    <head>
      <basefont face="verdana" size="1" color="black"/>
      <TITLE>Compatibility Report</TITLE>
    
    <style type="text/css">
    <xsl:comment>

body {
margin:30px;
}
#wrapper {
text-align:left;
margin:0 auto;
width:500px;
min-height:100px;
border:1px solid #ccc;
padding:30px;
}
a {
color:blue;
cursor:pointer;
}
.section {
border:1px solid #ccc;
background:#f2f2f2;
padding:20px;
display: block;
}
	</xsl:comment>

	</style>
<script type="text/javascript">
    <xsl:comment>

    <![CDATA[
function switchMenu(obj) {
	var el = document.getElementById(obj);
	var but = document.getElementById("button" + obj);
	if (el.style.display != "none" ) {
		el.style.display = 'none';
		but.innerHTML = "[+]" + but.innerHTML.substring(3);
	}
	else {
		el.style.display = 'block';
		but.innerHTML = "[-]" + but.innerHTML.substring(3);
	}
}
  ]]>

 </xsl:comment>

	</script>   
    </head>
    
    <body>
    <H1><font color="#000099">CDB Compatibility Report</font></H1>
        <xsl:apply-templates/>
        <p/>
        <hr/>
        <b>Api Classification of Breaks</b>
        <br/>
        <i>The color of the break description indicates the API classification of the item which is broken</i>
        <br/>
        <table border="0">
            <tr>
            <!--<xsl:value-of select="($access-status)"/>-->
            	<xsl:for-each select="($write_access_color)/access">
            	   <xsl:variable name="color">
            	   	<xsl:value-of select="color"/>
            	   </xsl:variable>
            	   			<td bgcolor="{$color}"><font size="1">&#160;</font></td>
            	   			<td><font size="1"><xsl:value-of select="id"/></font></td>
            	</xsl:for-each>
            </tr>  
         </table>
    </body>
    </HTML>
</xsl:template>




<!-- Add timestamp information -->
<xsl:template match="timestamp">
    <p>
    <table border="0">
        <tr>
            <td><font size="2"><b>This comparison performed:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@date"/>&#9; at &#9;</font></td>
            <td><font size="2"><xsl:value-of select="@time"/></font></td>
        </tr>
    </table>
    </p>
    <xsl:apply-templates/>
</xsl:template>




<!-- Add reference release information -->
<xsl:template match="referenceRelease">
    <table border="0">
        <tr>
            <td><font size="2"><b>Reference Configuration:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@config"/>&#9;</font></td>
            <td><font size="2"><xsl:value-of select="@version"/></font></td>
            <td><font size="2"><xsl:value-of select="@build"/></font></td>
        </tr>
    </table>
    <xsl:apply-templates/>
</xsl:template>




<!-- Add checked release information -->
<xsl:template match="checkedRelease">
         <font size="-1"/>
    <table border="0">
        <tr>
            <td><font size="2"><b>Checked Configuration:&#9;</b></font></td>
            <td><font size="2"><xsl:value-of select="@config"/>&#9;</font></td>
            <td><font size="2"><xsl:value-of select="@version"/></font></td>
            <td><font size="2"><xsl:value-of select="@build"/></font></td>
        </tr>
    </table> 
    <hr/>
    <xsl:apply-templates/>
</xsl:template>


<xsl:template match="summary">
    <table border="0" cellspacing="0">
    <font size="2"><b>Summary</b></font>
    <br/>
    <table>
    <xsl:apply-templates/>
    </table>
    </table>
    <hr/>
</xsl:template>


<xsl:template match="totalBreaks">
    <tr>
        <td><font size="1">Total number of breaks:</font></td>
        <td><font size="1" color="#000099"><xsl:value-of select="@count"/></font></td>
    </tr>
    <xsl:apply-templates/>
</xsl:template>


<xsl:template match="seriousBreaks">
    <tr>
        <td><font size="1">Breaks at level <b><xsl:value-of select="@aboveLevel"/></b> and above:</font></td>
        <td><font size="1" color="#000099"><xsl:value-of select="@count"/></font></td>
    </tr>
    <xsl:apply-templates/>
</xsl:template>


<xsl:template match="section">
   <xsl:variable name="section-name"><xsl:value-of select="@name"/></xsl:variable>
   <xsl:variable name="section-count"><xsl:value-of select="@count"/></xsl:variable>
   
   <button id="button{$section-name}" onclick="switchMenu('{$section-name}');"><xsl:value-of select="concat('[-] ', $section-name, '(', $section-count, ')')"/></button>
    <div id="{$section-name}" class="section">
     <xsl:apply-templates/>
    </div>
</xsl:template>

<!--match for a subsystem -->
<xsl:template match="subsystem">
    <br/><b><li/>SUBSYSTEM:&#9;<xsl:value-of select="@name"/></b><br/>
     <xsl:apply-templates/>
</xsl:template>


<xsl:template match="component">
    <b><li/>COMPONENT:&#9;<xsl:value-of select="@name"/></b><br/>
    <xsl:apply-templates/>
</xsl:template>    

<xsl:template match="executable">
    <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
    <xsl:apply-templates/>
</xsl:template>    



<!-- missing headers -->
<xsl:template match="break">
    <xsl:choose>
        <xsl:when test="@type='missingHeader'">
            <b><li/>HEADER FILE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
            <table border="1" cellspacing="0">
            <tr>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
            </tr>
            <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">Missing Header</xsl:with-param>
   	 			</xsl:apply-templates>
                <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
            </TR>
            </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='missingExe'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
            <table border="1" cellspacing="0">
            <tr>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
            </tr>
            <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">Missing Executable</xsl:with-param>
   	 			</xsl:apply-templates>
                <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
            </TR>
            </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeMMPFileChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got MMP File</b></font></td>
                </tr>
                <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">MMP File Changed</xsl:with-param>
   	 			</xsl:apply-templates>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeDefFileChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected DEF File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got DEF File</b></font></td>
                </tr>
                <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">DEF File Changed</xsl:with-param>
   	 			</xsl:apply-templates>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@mmpfile"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeTargetTypeChanged'">
            <b><li/>EXECUTABLE:&#9;<xsl:value-of select="@name"/></b><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>MMP File</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected Target Type</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got Target Type</b></font></td>
                </tr>
                <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">Targettype Changed</xsl:with-param>
   	 			</xsl:apply-templates>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@mmpfile"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='missingClass'">
            <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@header"/>)</font></i><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Could not Find</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
                <TR>
                   <xsl:call-template name="formatBreakCell">
                       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
                       <xsl:with-param name="nature"><xsl:value-of select="$classMissing"/></xsl:with-param>
                   </xsl:call-template>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='classAbstractnessChanged'">
            <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@header"/>)</font></i><br/>
            <p/>   
        
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Name</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
                <TR>
                   
                   <xsl:call-template name="formatBreakCell">
                       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
                       <xsl:with-param name="nature"><xsl:value-of select="$classAbstractnessChanged"/></xsl:with-param>
                   </xsl:call-template>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeUidChanged'">
        	  <p/>   
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
                </tr>
                <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">UID Changed</xsl:with-param>
   	 			</xsl:apply-templates>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
        <xsl:when test="@type='exeCapabilityChanged'">
        	        	  <p/>   
            <table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
                </tr>
                <TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature">Capability Changed</xsl:with-param>
   	 			</xsl:apply-templates>
                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                </TR>
                </table><p/><p/>
        </xsl:when>
    </xsl:choose>
</xsl:template>

<xsl:template match="resourceFile">
				<xsl:param name="ac"><xsl:value-of select="@access"/></xsl:param>
				<xsl:param name="st"><xsl:value-of select="@status"/></xsl:param>
				<b><li/>RESOURCE FILE:&#9;<xsl:value-of select="@name"/></b><br/>
				<table border="1" cellspacing="0">
                <tr>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
                    <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
					<td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
					<td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>
                </tr>
		<xsl:for-each select="break">
			   <xsl:choose>
			   		<xsl:when test="@type='resourceFileMissing'">
					<TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature"><xsl:value-of select="$resourceFileMissing"/></xsl:with-param>
   	 			</xsl:apply-templates>
	                    <TD>&#160;</TD>
	                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
	                    <TD>&#160;</TD>
	                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
	                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemChanged'">
					<TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature"><xsl:value-of select="$resourceItemChanged"/></xsl:with-param>
   	 			</xsl:apply-templates>
	                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
	                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
	                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemNameChanged'">
        				<TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature"><xsl:value-of select="$resourceItemNameChanged"/></xsl:with-param>
   	 			</xsl:apply-templates>
		                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemTypeChanged'">
        				<TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature"><xsl:value-of select="$resourceItemTypeChanged"/></xsl:with-param>
   	 			</xsl:apply-templates>
		                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/> </b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemMissing'">
        				<TR>
            	<xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				<xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				<xsl:with-param name="nature"><xsl:value-of select="$resourceItemMissing"/></xsl:with-param>
   	 			</xsl:apply-templates>
		                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemAdded'">
        				<TR>
		                    <xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				            <xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				        <xsl:with-param name="nature"><xsl:value-of select="$resourceItemAdded"/></xsl:with-param>
   	 			            </xsl:apply-templates>
                            <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceItemImpacted'">
        				<TR>
		                    <xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				            <xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				        <xsl:with-param name="nature"><xsl:value-of select="$resourceItemImpacted"/></xsl:with-param>
   	 			            </xsl:apply-templates>
                            <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        			<xsl:when test="@type='resourceOrderChanged'">
        				<TR>
		                    <xsl:apply-templates select="$write_access_color" mode="TableConstruct">
   	 				            <xsl:with-param name="curr-label">notApplicable</xsl:with-param>
    	 				        <xsl:with-param name="nature"><xsl:value-of select="$resourceOrderChanged"/></xsl:with-param>
   	 			            </xsl:apply-templates>
                            <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$ac"/></b></font></TD>
		                    <TD><font size="1"><b><xsl:value-of select="$st"/></b></font></TD>
		                </TR>
        			</xsl:when>
        		</xsl:choose>
		</xsl:for-each>
		</table><p/><p/>
</xsl:template>


<!-- deffile template -->
<xsl:template match="deffile">
    <b><li/>DEF FILE:&#9;<xsl:value-of select="@name"/></b><br/>
    <p/>
    <table border="1" cellspacing="0">
        <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>         
	</tr>        
           	
	     <xsl:for-each select="break">
		<TR>        
		<xsl:call-template name="formatBreakCell">
		       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>			
		       <xsl:with-param name="nature"><xsl:value-of select="@type"/></xsl:with-param>
		   </xsl:call-template>
		        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
        		<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
		        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
    			<TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
		        <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
		   </TR>
	    </xsl:for-each>
        
        </table><p/><p/>
</xsl:template>

<xsl:template match="classification">
    <b><li/>Entity:&#9;<xsl:value-of select="@name"/></b><br/>
    <p/>
    <table border="1" cellspacing="0">
        <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Entity</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>File</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>         
	</tr>        
           	
	     <xsl:for-each select="break">
		<TR>    
		        <xsl:call-template name="formatBreakCell">
               <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
               <xsl:with-param name="nature"><xsl:value-of select="@type"/></xsl:with-param>
           </xsl:call-template>
           <xsl:choose>
                <xsl:when test="@type='classificationTightened' or @type='classificationSlightlyTightened' or @type='classificationRemoved' or @type='classificationBroken' ">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                	<td><font size="1"><b><xsl:value-of select="@file"/></b></font></td>
                	<td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
				<xsl:otherwise>
               	</xsl:otherwise>
           </xsl:choose>
        </TR>
    </xsl:for-each>
        </table>
    <br/>
    <br/>
 </xsl:template>

<xsl:template match="inline">
	
	<b><li/>File Name: &#9;<xsl:value-of select="@file"/></b><br/>
	<b><li/>Class Name: &#9;<xsl:value-of select="@name"/></b><br/>
    <p/>
    
    <table border="1" cellspacing="0">
        <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Signature</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
		</tr>
		<xsl:for-each select="break">
		<tr>
			<xsl:call-template name="formatBreakCell">
		       <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
		       <xsl:with-param name="nature"><xsl:value-of select="@type"/></xsl:with-param>
			</xsl:call-template>
			<xsl:choose>
			<xsl:when test="@type='inlineFunctionMissing'">
        		
				<td><font size="1"><b><xsl:value-of select="@line"/></b></font></td>
				<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
				<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
				<td>&#160;</td>
			</xsl:when>
			<xsl:when test="@type='inlineFunctionSignatureChanged'">
        		
				<td><font size="1"><b><xsl:value-of select="@line"/></b></font></td>
				<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
				<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
				<td><font size="1"><b><xsl:value-of select="@got"/></b></font></td>
			</xsl:when>
			</xsl:choose>
		</tr>    
		</xsl:for-each>    
    </table>
	
    <p/><p/>
</xsl:template>

<!-- class related matches -->
<xsl:template match="class">
    
    <b><li/>CLASS:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@file"/>)</font></i><br/>
    <p/>   
    
    <!-- class headings -->
    <table border="1" cellspacing="0">
    <colgroup/>
    <colgroup span="3"/>
    <colgroup span="3" bgcolor="#ffffff"/>
    <colgroup span="2"/>    
    <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>         
    </tr>
 	
    <xsl:for-each select="break">
     		   <TR>
           <xsl:call-template name="formatBreakCell">
               <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
               <xsl:with-param name="nature"><xsl:value-of select="@type"/></xsl:with-param>
           </xsl:call-template>
           <xsl:choose>
                <xsl:when test="@type='vtblItemAdded'">
                	<td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblItemMissing'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='datumAdded'">
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='datumMissing'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classLayoutBreak'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classSizeChanged'">
                	<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classSizeChangedMemberData'">
                	<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classSizeChangedVtableAdded'">
                	<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classSizeChangedVtableRemoved'">
                	<TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='classificationTightened'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                	<td><font size="1"><b><xsl:value-of select="@file"/></b></font></td>
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblLayoutChanged'">
                	<td><font size="1"><b><xsl:value-of select="@expected"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@gotposition"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='vtblOverrideBreak'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='missingEnum'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
                <xsl:when test="@type='anonymousEnumBreak'">
                	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <td>&#160;</td>
                    <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                    <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                </xsl:when>
		<xsl:when test="@type='constantMissing'">
                  	<td><font size="1"><b><xsl:value-of select="@name"/></b></font></td>
                      <td>&#160;</td>
                      <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                      <td>&#160;</td>
                      <td>&#160;</td>
                      <td>&#160;</td>
                      <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                      <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                  </xsl:when>
		  <xsl:when test="@type='resourceMissing'">
                  	<td><font size="1"><b><xsl:value-of select="@resourcename"/></b></font></td>
                      <td><font size="1"><b><xsl:value-of select="@position"/></b></font></td>
                      <td>&#160;</td>
                      <td>&#160;</td>
                      <td>&#160;</td>
                      <td>&#160;</td>
                      <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
                      <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
                  </xsl:when>
                <xsl:otherwise>
                </xsl:otherwise>
           </xsl:choose>
        </TR>
    </xsl:for-each>
    
    <xsl:for-each select="enum">
             <TR/><TR/>
         <TR>
             <TD colspan="9" bgcolor="#000000" height="5"></TD>
         </TR>
        <TR>
            <xsl:call-template name="formatBreakCell">
               <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
               <xsl:with-param name="nature"><xsl:value-of select="@name"/></xsl:with-param>
               <xsl:with-param name="width">7</xsl:with-param>
            </xsl:call-template>
            <TD><font size="1"><b>&#160;</b></font></TD>
            <TD><font size="1"><b>&#160;</b></font></TD>
            <TD><font size="1"><b>&#160;</b></font></TD>
            <TD><font size="1"><b>&#160;</b></font></TD>
            <TD><font size="1"><b>&#160;</b></font></TD>
            <TD><font size="1"><b>&#160;</b></font></TD>
	        <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
	        <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>
        </TR>
        <TR>
            <TD colspan="9" bgcolor="#000000" height="5"></TD>
        </TR>
        
        <xsl:for-each select="break">
            <xsl:choose>
                <xsl:when test="@type='addedEnumItem'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueAdded"/></i></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='missingEnumItem'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumMissingValue"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='enumItemNameChanged'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueChangedName"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
                <xsl:when test="@type='enumItemValueChanged'">
                    <tr>
                        <TD><font size="1"><i><xsl:value-of select="$enumValueChangedValue"/></i></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expected"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@position"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@expline"/></b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@got"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b><xsl:value-of select="@gotline"/></b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                        <TD><font size="1"><b>&#160;</b></font></TD>
                    </tr>
                </xsl:when>
            </xsl:choose>
        </xsl:for-each>
    </xsl:for-each>
    </table>
    <br/>
    <br/>
 </xsl:template>

<!-- class related matches -->
<xsl:template match="header">
    
    <b><li/>HEADER:&#9;<xsl:value-of select="@name"/>&#160;&#160;&#160;</b><i><font color="gray">(<xsl:value-of select="@name"/>)</font></i><br/>
    <p/>   
    
    <!-- class headings -->
    <table border="1" cellspacing="0">
    <colgroup/>
    <colgroup span="3"/>
    <colgroup span="3" bgcolor="#ffffff"/>
    <colgroup span="2"/>    
    <tr>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Break</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Expected</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Got</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Position</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Line</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Access</b></font></td>
        <td bgcolor="#000099"><font size="1" color="#ffffff"><b>Status</b></font></td>         
    </tr>
 		
	<xsl:for-each select="break">
	<TR>
              <xsl:call-template name="formatBreakCell">
                 <xsl:with-param name="access"><xsl:value-of select="@access"/></xsl:with-param>
                 <xsl:with-param name="nature"><xsl:value-of select="@name"/></xsl:with-param>
                 <xsl:with-param name="width">7</xsl:with-param>
              </xsl:call-template>
              </TR>
	<TR>
                <xsl:choose>
                 <xsl:when test="@type='constantMissing'">

                          <TD><font size="1"><i><xsl:value-of select="$constMissing"/></i></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@name"/></b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
			  <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>

                  </xsl:when>
                  <xsl:when test="@type='constValueChanged'">

                          <TD><font size="1"><i><xsl:value-of select="$constValueChanged"/></i></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@name"/>=<xsl:value-of select="@expected"/></b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
			  <TD><font size="1"><b><xsl:value-of select="@line"/></b></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@name"/>=<xsl:value-of select="@got"/></b></font></TD>
                          <TD><font size="1"><b>&#160;</b></font></TD>
			  <TD><font size="1"><b>&#160;</b></font></TD>
                          <TD><font size="1"><b><xsl:value-of select="@access"/></b></font></TD>
			  <TD><font size="1"><b><xsl:value-of select="@status"/></b></font></TD>

                   </xsl:when>
                   <xsl:otherwise>
                   </xsl:otherwise>
            </xsl:choose>
        </TR>
      </xsl:for-each>             
	
	</table>
    <br/>
    <br/>
 </xsl:template>

<xsl:template match="userdefined" mode="BreakCellFormat">
  <xsl:param name="curr-label"/>
  <xsl:param name="nature"/>
  <xsl:param name="width">1</xsl:param>
  <xsl:param name="color"><xsl:value-of select="key('access-lookup', $curr-label)/color"/></xsl:param>
  <td colspan="{$width}"><font size="1" color="{$color}"><b><xsl:value-of select="$nature"/></b></font></td> 
 </xsl:template>
 
 <xsl:template match="userdefined" mode="TableConstruct">
  <xsl:param name="curr-label"/>
  <xsl:param name="nature"/>
  <xsl:param name="color"><xsl:value-of select="key('access-lookup', $curr-label)/color"/></xsl:param>
  <TD><font size="1" color="{$color}"><b><xsl:value-of select="$nature"/></b></font></TD>
  
 </xsl:template>

<!-- template to handle break cell colouring -->

<xsl:template name="formatBreakCell">
    <xsl:param name="access"/>
    <xsl:param name="nature"/>

     <xsl:param name="width">1</xsl:param>
       <xsl:apply-templates select="$write_access_color" mode="BreakCellFormat">
   	 	<xsl:with-param name="curr-label" select="@access"/>
   	 	<xsl:with-param name="nature" select="$nature"/>
   	 </xsl:apply-templates>
</xsl:template>
    

</xsl:stylesheet>
